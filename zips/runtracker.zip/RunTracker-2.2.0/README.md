# RunTracker
A application to keep track of track times/goals. Also contains a few features

officially on https://concerned-baby.github.io/runtracker/main%20menu

this program assumes that you have python built as a path, if not, do so.

If you have any difficulties, reach me at spencerye425@gmail.com
