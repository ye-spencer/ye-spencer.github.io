import uninstall
"""
Add screen
"""
def main():
	uninstall.start()

if __name__ == "__main__":
	main()
