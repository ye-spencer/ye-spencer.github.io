def bestHelp():
	return "This Page Displays The Best Talent At Each Event\n\nYou Can't Do Anything About It\n\n(Give Time To Update Dipshit)"

def predictorHelp():
	return """This Page Is Used For Creating Predictors Of Your Current And Future Possible Times\n

	Steps: 
	1) Select A Transformation From The Drop-Down Menu
	2) Enter Your Time For The Given Event 
	(From The First Event Given In The Selected Transformation)
	3) Click GO!

	Note:
	[Best] 		means the best time achieveable within a season
	[Estimate] 	means the time you can probably run right now

	The Predicted Time For The Second Event Will Appear In The Lowest Text Box
	"""

def menuHelp():
	return """This Is A Program to Help You Keep "Track"(pun intended) Of Everything\n
	Click Any Button To Get Started, Read The Help On Each page If Needed
	"""

def selectHelp():
	return """ This Page Allows You To Go To Any [listed] Runners Page
	Select A Runner And Click "GO!".
	If that's not for you, consider adding new runners
	"""

def runnerHelp():
	return """This Page Displays All The Given Information About A Runner
	It Also Allows You To Update Any Information
	"""

def editEventsHelp():
	return """Here You Can Add and Remove Events From A Runner
	Simply Check and Uncheck the boxes"""

def editTimesHelp():
	return """Here You Can Add Times To A Runner
	Just Select A Event and Enter A Time """

def editGoalsHelp():
	return """Here You Can Add Goals For A Runner
	Just Select A Event and Enter A Goal"""

def advancedHelp():
	return """Here You Can Look At Some More Advanced Measures of Skill and Ability"""

def selectNewHelp():
	return """Here You Can Create A New Runner To Add Information To"""

def aboutus():
	return """RunTracker [v2.0.1] is developed by a runner and coder from the bay area.
	Look at other similar projects at https://concerned-baby.github.io/\n\nClick 'Sign-Up' below for track program"""
